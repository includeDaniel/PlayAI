import pygame
import os
import random
import neat

# --- GLOBAL CONFIG AND CONSTANTS ---

WINDOW_WIDTH = 500
WINDOW_HEIGHT = 800
GROUND_Y = 730
GAME_CLOCK_TICK = 45

AI_PLAYING = True
GENERATION = 0

BASE_SPEED = 5
BASE_PIPE_DISTANCE = 140
SPEED_MULTIPLIER = 1.01

# --- TUNED PARAMETERS FOR BALANCED PROGRESSION ---
MAX_PIPE_SPEED = 25             # Maximum horizontal speed for pipes
MAX_PIPE_DISTANCE = 650         # Maximum allowed spawn distance
PIPE_DISTANCE_GROWTH_RATE = 1.03  # Moderate exponential growth
PIPE_DISTANCE_LINEAR = 6        # Linear distance gain per point
MAX_PIPE_DISTANCE_EXP = 600     # Cap for exponential growth distance

pygame.init()
pygame.font.init()
pygame.mixer.init()

SCORE_FONT = pygame.font.SysFont('roboto', 20)


# --- ASSET LOADING ---

def load_assets():
    """
    Loads all game assets (images and sounds) from the assets folder.
    Returns a dictionary containing all loaded resources.
    """
    assets_folder = 'assets'
    ground_img = pygame.transform.scale2x(pygame.image.load(os.path.join(assets_folder, 'base.png')))
    background_img = pygame.transform.scale2x(pygame.image.load(os.path.join(assets_folder, 'bg.png')))
    pipe_img = pygame.transform.scale2x(pygame.image.load(os.path.join(assets_folder, 'pipe.png')))
    bird_imgs = [
        pygame.transform.scale2x(pygame.image.load(os.path.join(assets_folder, 'bird1.png'))),
        pygame.transform.scale2x(pygame.image.load(os.path.join(assets_folder, 'bird2.png'))),
        pygame.transform.scale2x(pygame.image.load(os.path.join(assets_folder, 'bird3.png'))),
    ]
    jump_sfx = pygame.mixer.Sound(os.path.join(assets_folder, 'jump.mp3'))
    point_sfx = pygame.mixer.Sound(os.path.join(assets_folder, 'point.mp3'))
    return {
        'ground': ground_img,
        'background': background_img,
        'pipe': pipe_img,
        'birds': bird_imgs,
        'jump_sound': jump_sfx,
        'point_sound': point_sfx
    }


ASSETS = load_assets()
JUMP_SOUND = ASSETS['jump_sound']
POINT_SOUND = ASSETS['point_sound']


# --- BIRD CLASS ---

class Bird:
    """
    Represents the flappy bird character.
    Handles physics, movement, rotation, and wing animation.
    """
    IMGS = ASSETS['birds']
    MAX_ROTATION = 25
    ROTATION_SPEED = 20
    ANIMATION_TIME = 5

    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.angle = 0
        self.speed = 0
        self.height = self.y
        self.time = 0
        self.image_index = 0
        self.image = self.IMGS[0]

    def jump(self):
        """Makes the bird jump upward and plays a sound."""
        self.speed = -10.5
        self.time = 0
        self.height = self.y
        JUMP_SOUND.play()

    def move(self):
        """Handles gravity, movement arc, and rotation."""
        self.time += 1
        displacement = 1.5 * (self.time ** 2) + self.speed * self.time
        if displacement > 16:
            displacement = 16
        elif displacement < 0:
            displacement -= 2
        self.y += displacement

        # Rotation control
        if displacement < 0 or self.y < (self.height + 50):
            if self.angle < self.MAX_ROTATION:
                self.angle = self.MAX_ROTATION
        else:
            if self.angle > -90:
                self.angle -= self.ROTATION_SPEED

    def draw(self, window):
        """Draws the bird with wing animation and rotation."""
        self.image_index += 1
        if self.image_index < self.ANIMATION_TIME:
            self.image = self.IMGS[0]
        elif self.image_index < self.ANIMATION_TIME * 2:
            self.image = self.IMGS[1]
        elif self.image_index < self.ANIMATION_TIME * 3:
            self.image = self.IMGS[2]
        elif self.image_index < self.ANIMATION_TIME * 4:
            self.image = self.IMGS[1]
        elif self.image_index >= self.ANIMATION_TIME * 4 + 1:
            self.image = self.IMGS[0]
            self.image_index = 0

        if self.angle <= -80:
            self.image = self.IMGS[1]
            self.image_index = self.ANIMATION_TIME * 2

        rotation_image = pygame.transform.rotate(self.image, self.angle)
        original_center = self.image.get_rect(topleft=(self.x, self.y)).center
        rotated_rect = rotation_image.get_rect(center=original_center)
        window.blit(rotation_image, rotated_rect.topleft)

    def get_mask(self):
        """Returns a mask for pixel-perfect collision detection."""
        return pygame.mask.from_surface(self.image)


# --- PIPE CLASS ---

class Pipe:
    """
    Represents an upper and lower pipe pair.
    Controls height randomization, movement, and collision detection.
    """
    IMAGE = ASSETS['pipe']
    GAP = 160
    SPEED = BASE_SPEED

    def __init__(self, x):
        self.x = x
        self.height = 0
        self.top_position = 0
        self.base_position = 0
        self.top_pipe = pygame.transform.flip(self.IMAGE, False, True)
        self.pipe_base = self.IMAGE
        self.passed = False
        self._set_height()

    def _set_height(self):
        """Randomizes the vertical position of the pipe gap."""
        self.height = random.randrange(50, 450)
        self.top_position = self.height - self.top_pipe.get_height()
        self.base_position = self.height + self.GAP

    def move(self):
        """Moves the pipe horizontally across the screen."""
        self.x -= Pipe.SPEED

    def draw(self, window):
        """Draws both the top and bottom pipes on the window."""
        window.blit(self.top_pipe, (self.x, self.top_position))
        window.blit(self.pipe_base, (self.x, self.base_position))

    def colide(self, bird):
        """Checks for pixel-perfect collision with a bird."""
        bird_mask = bird.get_mask()
        top_mask = pygame.mask.from_surface(self.top_pipe)
        base_mask = pygame.mask.from_surface(self.pipe_base)
        top_offset = (self.x - bird.x, self.top_position - round(bird.y))
        base_offset = (self.x - bird.x, self.base_position - round(bird.y))
        top_point = bird_mask.overlap(top_mask, top_offset)
        base_point = bird_mask.overlap(base_mask, base_offset)
        return bool(base_point or top_point)


# --- GROUND CLASS ---

class Ground:
    """
    Represents the scrolling ground.
    Creates an infinite loop illusion by moving two ground images.
    """
    IMAGE = ASSETS['ground']
    SPEED = BASE_SPEED
    WIDTH = IMAGE.get_width()

    def __init__(self, y):
        self.y = y
        self.x1 = 0
        self.x2 = self.WIDTH

    def move(self):
        """Moves the ground to simulate continuous scrolling."""
        self.x1 -= self.SPEED
        self.x2 -= self.SPEED
        if self.x1 + self.WIDTH < 0:
            self.x1 = self.x2 + self.WIDTH
        if self.x2 + self.WIDTH < 0:
            self.x2 = self.x1 + self.WIDTH

    def draw(self, window):
        """Draws both ground segments."""
        window.blit(self.IMAGE, (self.x1, self.y))
        window.blit(self.IMAGE, (self.x2, self.y))


# --- DRAWING AND UTILITY FUNCTIONS ---

def draw_window(window, birds, pipes, ground, score):
    """
    Draws all game elements (background, pipes, birds, ground, and score).
    """
    window.blit(ASSETS['background'], (0, 0))
    for pipe in pipes:
        pipe.draw(window)
    for bird in birds:
        bird.draw(window)
    ground.draw(window)
    score_text = SCORE_FONT.render(f"Score: {score}", 1, (255, 255, 255))
    window.blit(score_text, (WINDOW_WIDTH - 10 - score_text.get_width(), 10))
    if AI_PLAYING:
        gen_text = SCORE_FONT.render(f"Generation: {GENERATION}", 1, (255, 255, 255))
        window.blit(gen_text, (10, 10))
    pygame.display.update()


def spawn_pipe_if_needed(pipes, points):
    """
    Dynamically spawns new pipes as the game progresses.
    Balances speed and spacing to avoid unrealistic difficulty spikes.
    """
    # Gradually increase speed but cap it
    new_speed = BASE_SPEED + min(points * 0.12, MAX_PIPE_SPEED - BASE_SPEED)
    Pipe.SPEED = min(new_speed, MAX_PIPE_SPEED)
    Ground.SPEED = Pipe.SPEED

    # Calculate pipe spacing (exponential + linear with cap)
    exp_distance = int(BASE_PIPE_DISTANCE * (PIPE_DISTANCE_GROWTH_RATE ** points))
    linear_distance = BASE_PIPE_DISTANCE + PIPE_DISTANCE_LINEAR * points
    new_pipe_distance = min(max(exp_distance, linear_distance), MAX_PIPE_DISTANCE_EXP, MAX_PIPE_DISTANCE)

    last_pipe = pipes[-1] if pipes else None
    spawn_x = WINDOW_WIDTH + new_pipe_distance
    min_gap_x = WINDOW_WIDTH - 40

    if last_pipe is None or last_pipe.x + last_pipe.top_pipe.get_width() < min_gap_x:
        new_pipe = Pipe(spawn_x)
        pipes.append(new_pipe)
        return new_pipe

    return None


# --- MAIN GAME LOOP ---

def main(genomes, config):
    """
    Main game loop that handles physics, AI input, scoring,
    pipe spawning, and rendering for every frame.
    """
    global GENERATION
    GENERATION += 1

    birds, networks, genomes_list = [], [], []
    if AI_PLAYING:
        for _, genome in genomes:
            network = neat.nn.FeedForwardNetwork.create(genome, config)
            networks.append(network)
            genome.fitness = 0
            genomes_list.append(genome)
            birds.append(Bird(230, 350))
    else:
        birds = [Bird(230, 350)]

    ground = Ground(GROUND_Y)
    pipes = [Pipe(700)]
    window = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
    points = 0
    clock = pygame.time.Clock()
    running = True

    while running:
        clock.tick(GAME_CLOCK_TICK)

        # --- Event handling ---
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                pygame.quit()
                quit()
            if not AI_PLAYING and event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
                for bird in birds:
                    bird.jump()

        if not birds:
            running = False
            break

        if not pipes:
            pipes.append(Pipe(WINDOW_WIDTH))

        # --- Pipe logic ---
        pipe_index = 0
        if len(pipes) > 1 and birds[0].x > pipes[0].x + pipes[0].top_pipe.get_width():
            pipe_index = 1
        current_pipe = pipes[pipe_index]

        # --- Bird logic ---
        for i, bird in enumerate(birds):
            bird.move()
            if AI_PLAYING:
                genomes_list[i].fitness += 0.1
                output = networks[i].activate((
                    bird.y,
                    abs(bird.y - current_pipe.height),
                    abs(bird.y - current_pipe.base_position)
                ))
                if output[0] > 0.5:
                    bird.jump()

        ground.move()

        # --- Pipe movement and collision ---
        add_pipe = False
        removed_pipes = []
        for pipe in pipes:
            pipe.move()
            for i in reversed(range(len(birds))):
                bird = birds[i]
                if pipe.colide(bird):
                    birds.pop(i)
                    if AI_PLAYING:
                        genomes_list[i].fitness -= 1
                        genomes_list.pop(i)
                        networks.pop(i)
                        continue
                if not pipe.passed and bird.x > pipe.x:
                    pipe.passed = True
                    add_pipe = True
            if pipe.x + pipe.top_pipe.get_width() < 0:
                removed_pipes.append(pipe)

        # --- Add new pipes with balanced delay ---
        if add_pipe:
            points += 1
            POINT_SOUND.play()
            spawn_pipe_if_needed(pipes, points)
            if AI_PLAYING:
                for genome in genomes_list:
                    genome.fitness += 5

        # --- Remove off-screen pipes ---
        for pipe in removed_pipes:
            pipes.remove(pipe)

        # --- Remove dead birds ---
        for i in reversed(range(len(birds))):
            bird = birds[i]
            if bird.y + bird.image.get_height() > ground.y or bird.y < 0:
                birds.pop(i)
                if AI_PLAYING:
                    genomes_list.pop(i)
                    networks.pop(i)

        draw_window(window, birds, pipes, ground, points)


# --- NEAT CONFIG AND EXECUTION ---

def run_neat_simulation(config_path):
    """
    Initializes and runs the NEAT population for AI-based training.
    """
    config = neat.config.Config(
        neat.DefaultGenome,
        neat.DefaultReproduction,
        neat.DefaultSpeciesSet,
        neat.DefaultStagnation,
        config_path
    )
    population = neat.Population(config)
    population.add_reporter(neat.StdOutReporter(True))
    population.add_reporter(neat.StatisticsReporter())

    if AI_PLAYING:
        population.run(main, 100)
    else:
        main(None, None)


# --- ENTRY POINT ---

if __name__ == '__main__':
    current_dir = os.path.dirname(__file__)
    config_file_path = os.path.join(current_dir, 'configs.txt')
    Ground.SPEED = BASE_SPEED
    Pipe.SPEED = BASE_SPEED
    run_neat_simulation(config_file_path)
